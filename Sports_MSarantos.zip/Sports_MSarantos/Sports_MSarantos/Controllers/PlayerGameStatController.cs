﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Sports_MSarantos.Models;

namespace Sports_MSarantos.Controllers
{
    public class PlayerGameStatController : Controller
    {
        private Sports_MSarantosContext db = new Sports_MSarantosContext();

        // GET: /PlayerGameStat/
        public ActionResult Index()
        {
            var playergamestats = db.PlayerGameStats.Include(p => p.Game).Include(p => p.Player);
            return View(playergamestats.ToList());
        }

        // GET: /PlayerGameStat/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PlayerGameStat playergamestat = db.PlayerGameStats.Find(id);
            if (playergamestat == null)
            {
                return HttpNotFound();
            }
            return View(playergamestat);
        }

        // GET: /PlayerGameStat/Create
        public ActionResult Create()
        {
            ViewBag.GameID = new SelectList(db.Games, "GameID", "GameName");
            ViewBag.PlayerID = new SelectList(db.Players, "PlayerID", "PlayerName");
            return View();
        }

        // POST: /PlayerGameStat/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="PlayerGameStatID,GameID,PlayerID,ShotsOnGoal,CreateDate")] PlayerGameStat playergamestat)
        {
            if (ModelState.IsValid)
            {
                db.PlayerGameStats.Add(playergamestat);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.GameID = new SelectList(db.Games, "GameID", "GameName", playergamestat.GameID);
            ViewBag.PlayerID = new SelectList(db.Players, "PlayerID", "PlayerName", playergamestat.PlayerID);
            return View(playergamestat);
        }

        // GET: /PlayerGameStat/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PlayerGameStat playergamestat = db.PlayerGameStats.Find(id);
            if (playergamestat == null)
            {
                return HttpNotFound();
            }
            ViewBag.GameID = new SelectList(db.Games, "GameID", "GameName", playergamestat.GameID);
            ViewBag.PlayerID = new SelectList(db.Players, "PlayerID", "PlayerName", playergamestat.PlayerID);
            return View(playergamestat);
        }

        // POST: /PlayerGameStat/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="PlayerGameStatID,GameID,PlayerID,ShotsOnGoal,CreateDate")] PlayerGameStat playergamestat)
        {
            if (ModelState.IsValid)
            {
                db.Entry(playergamestat).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.GameID = new SelectList(db.Games, "GameID", "GameName", playergamestat.GameID);
            ViewBag.PlayerID = new SelectList(db.Players, "PlayerID", "PlayerName", playergamestat.PlayerID);
            return View(playergamestat);
        }

        // GET: /PlayerGameStat/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PlayerGameStat playergamestat = db.PlayerGameStats.Find(id);
            if (playergamestat == null)
            {
                return HttpNotFound();
            }
            return View(playergamestat);
        }

        // POST: /PlayerGameStat/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            PlayerGameStat playergamestat = db.PlayerGameStats.Find(id);
            db.PlayerGameStats.Remove(playergamestat);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
