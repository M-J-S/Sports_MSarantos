﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Sports_MSarantos.Startup))]
namespace Sports_MSarantos
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
