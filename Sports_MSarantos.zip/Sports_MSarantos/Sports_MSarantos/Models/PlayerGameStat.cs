﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Sports_MSarantos.Models
{
    
    
    public class PlayerGameStat
    {
        [Key]
        public int PlayerGameStatID { get; set; }

        [Required]
        public int GameID { get; set; }
        [ForeignKey("GameID")]
        public virtual Game Game { get; set; }

       
        [Required]
        public int PlayerID { get; set; }
        [ForeignKey("PlayerID")]
        public virtual Player Player { get; set; }
        

        [Required]
        [Range(0, int.MaxValue, ErrorMessage = "ShotsOnGoal must be a non negative number")]
        public int ShotsOnGoal { get; set; }

        DateTime _date = DateTime.Now;
        [Required]
        public DateTime CreateDate
        {
            get { return _date; }
            set { _date = value; }
        }
    }
}