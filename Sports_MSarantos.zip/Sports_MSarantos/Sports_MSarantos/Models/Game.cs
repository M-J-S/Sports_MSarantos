﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace Sports_MSarantos.Models
{
    public class Game
    {
        [Key]
        public int GameID { get; set; }

        [StringLength(100)]
        [Required]
        public string GameName { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime GameDate { get; set; }

        DateTime _date = DateTime.Now;
        [Required]
        public DateTime CreateDate
        {
            get { return _date; }
            set { _date = value; }
        }
    }

}