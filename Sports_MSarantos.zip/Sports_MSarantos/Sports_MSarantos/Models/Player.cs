﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Sports_MSarantos.Models
{
    public class Player
    {
        [Key]
        public int PlayerID { get; set; }

        [StringLength(100)]
        [Required]
        public String PlayerName { get; set; }

        [DataType(DataType.Date)]
        public DateTime DateOfBirth { get; set; }

        DateTime _date = DateTime.Now;
        [Required]
        public DateTime CreateDate
        {
            get { return _date; }
            set { _date = value; }
        }

    }
}